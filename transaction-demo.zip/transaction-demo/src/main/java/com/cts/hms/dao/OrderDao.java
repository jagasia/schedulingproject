package com.cts.hms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.hms.entity.Order;

@Repository
public interface OrderDao {

	int create(Order order);

	List<Order> read();

	Order read(Long id);

	int update(Order order);

	int delete(Long id);

	List<Order> findOrdersByCustomer(Long customer_id);
}