package com.cts.hms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cts.hms.entity.Cart;

@Component
public class CartDaoImpl implements CartDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(Cart cart) {
		return jdbcTemplate.update("INSERT INTO CART VALUES (?,?,?)", cart.getId(), cart.getCustomerId(), cart.getProductId());
	}
	@Override
	public List<Cart> read() {
		return jdbcTemplate.query("SELECT * FROM CART", new CartRowMapper());
	}
	@Override
	public Cart read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM CART WHERE id=?", new CartRowMapper(), id);
	}
	@Override
	public int update(Cart cart) {
		return jdbcTemplate.update("UPDATE CART SET customer_id=?, product_id=?, WHERE id=?", cart.getCustomerId(), cart.getProductId(), cart.getId());
	}
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM CART WHERE id=?",id);
	}
	@Override
	public List<Cart> cartByCustomerId(Long id)
	{
		return jdbcTemplate.query("SELECT * FROM Cart WHERE customer_id=?", new CartRowMapper(), id);
	}
}
