package com.cts.hms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cts.hms.entity.Schedule;

@Component
public class ScheduleDaoImpl implements ScheduleDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(Schedule schedule) {
		String sql="INSERT INTO Schedule VALUES (?,?,?,?,?)";
		return jdbcTemplate.update(sql, schedule.getId(), schedule.getRoute_id(), schedule.getFlight_id(), schedule.getSdate(), schedule.getStime());
	}
	@Override
	public List<Schedule> read() {
		String sql="SELECT * FROM Schedule";
		return jdbcTemplate.query(sql, new ScheduleRowMapper());
	}
	@Override
	public Schedule read(Long id) {
		String sql="select * from Schedule WHERE id=?";
		return jdbcTemplate.queryForObject(sql, new ScheduleRowMapper(), id);
	}
	@Override
	public int update(Schedule schedule) {
		String sql="UPDATE Schedule SET route_id=?, flight_id=?, sdate=?, stime=? WHERE id=?";
		return jdbcTemplate.update(sql, schedule.getRoute_id(), schedule.getFlight_id(), schedule.getSdate(), schedule.getStime(), schedule.getId());
	}
	@Override
	public int delete(Long id) {
		String sql="DELETE FROM Schedule WHERE id=?";
		return jdbcTemplate.update(sql, id);
	}
	@Override
	public List<Schedule> findScheduleBySourceDestination(String source, String destination)
	{
		String sql="SELECT * FROM Schedule WHERE source=? and destination=?";
		return jdbcTemplate.query(sql, new ScheduleRowMapper(),source, destination);
	}
	
}
