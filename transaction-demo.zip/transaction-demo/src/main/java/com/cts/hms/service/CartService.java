package com.cts.hms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.hms.dao.CartDao;
import com.cts.hms.entity.Cart;

@Service
public class CartService {
	@Autowired
	private CartDao cdao;
	
	public int create(Cart cart)
	{
		return cdao.create(cart);
	}

	public List<Cart> read()
	{
		return cdao.read();
	}

	public Cart read(Long id)
	{
		return cdao.read(id);
	}

	public int update(Cart cart)
	{
		return cdao.update(cart);
	}

	public int delete(Long id)
	{
		return cdao.delete(id);
	}
	
	public List<Cart> findCartItemsByCustomerId(Long id)
	{
		return cdao.cartByCustomerId(id);
	}
}
