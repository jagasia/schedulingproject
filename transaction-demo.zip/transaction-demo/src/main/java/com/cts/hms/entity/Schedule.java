package com.cts.hms.entity;

import java.time.LocalTime;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Schedule {
	private Long id;
	private Long route_id;
	private Long flight_id;
	private Date sdate;	
	private LocalTime stime;
	private int repeat;
	public Schedule() {}
	public Schedule(Long id, Long route_id, Long flight_id, Date sdate, LocalTime stime) {
		super();
		this.id = id;
		this.route_id = route_id;
		this.flight_id = flight_id;
		this.sdate = sdate;
		this.stime = stime;
	}
	
	public Schedule(Long id, Long route_id, Long flight_id, Date sdate, LocalTime stime, int repeat) {
		super();
		this.id = id;
		this.route_id = route_id;
		this.flight_id = flight_id;
		this.sdate = sdate;
		this.stime = stime;
		this.repeat = repeat;
	}
	
	public int getRepeat() {
		return repeat;
	}
	public void setRepeat(int repeat) {
		this.repeat = repeat;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getRoute_id() {
		return route_id;
	}
	public void setRoute_id(Long route_id) {
		this.route_id = route_id;
	}
	public Long getFlight_id() {
		return flight_id;
	}
	public void setFlight_id(Long flight_id) {
		this.flight_id = flight_id;
	}
	public Date getSdate() {
		return sdate;
	}
	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}
	public LocalTime getStime() {
		return stime;
	}
	public void setStime(LocalTime stime) {
		this.stime = stime;
	}
	@Override
	public String toString() {
		return "Schedule [id=" + id + ", route_id=" + route_id + ", flight_id=" + flight_id + ", sdate=" + sdate
				+ ", stime=" + stime + "]";
	}
	
}
