package com.cts.hms.entity;

import java.util.Date;

public class Order {
	private Long id;
	private Date orderDate;
	private Long productId;
	private Long customerId;
	private Long quantity;
	public Order()
	{
		
	}
	public Order(Long id, Date orderDate, Long productId, Long customerId, Long quantity) {
		super();
		this.id = id;
		this.orderDate = orderDate;
		this.productId = productId;
		this.customerId = customerId;
		this.quantity = quantity;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", orderDate=" + orderDate + ", productId=" + productId + ", customerId="
				+ customerId + ", quantity=" + quantity + "]";
	}
	
}
