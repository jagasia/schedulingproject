package com.cts.hms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;

import org.springframework.jdbc.core.RowMapper;

import com.cts.hms.entity.Schedule;

public class ScheduleRowMapper implements RowMapper<Schedule>
{

	@Override
	public Schedule mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2=new SimpleDateFormat("HH:mm:ss");
		String str=rs.getString(5);
		LocalTime lt=LocalTime.parse(str);
	
		try {
			return new Schedule(rs.getLong(1), rs.getLong(2), rs.getLong(3), sdf.parse(rs.getString(4)), lt);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
