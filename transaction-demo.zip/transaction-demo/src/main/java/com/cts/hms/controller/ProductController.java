package com.cts.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hms.entity.Product;
import com.cts.hms.service.ProductService;

@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class ProductController {
	@Autowired
	private ProductService cs;
	
	@PostMapping("/product")
	public int signup(@RequestBody Product product)
	{
		return cs.create(product);
	}
	
	@GetMapping("/product")
	public List<Product> getAllProducts()
	{
		return cs.read();
	}
	
	@GetMapping("/product/{id}")
	public Product findProductById(@PathVariable Long id)
	{
		return cs.read(id);
	}
	
	@GetMapping("/product/category/{category}")
	public List<Product> findProductsByCategory(@PathVariable String category)
	{
		return cs.findProductsByCategory(category);
	}
	
	@GetMapping("/product/categories")
	public List<String> getCategories()
	{
		return cs.getCategories();
	}
	
	@PutMapping("/product")
	public int modifyProduct(@RequestBody Product product)
	{
		return cs.update(product);
	}
	
	@DeleteMapping("/product/{id}")
	public int removeProduct(@PathVariable Long id)
	{
		return cs.delete(id);
	}
}
