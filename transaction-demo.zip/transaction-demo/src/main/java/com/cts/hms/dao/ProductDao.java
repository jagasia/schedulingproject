package com.cts.hms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.hms.entity.Product;

@Repository
public interface ProductDao {

	int create(Product product);

	List<Product> read();

	Product read(Long id);

	int update(Product product);

	int delete(Long id);

	public List<Product> findProductsByCategory(String category);
	
	public List<String> getCategories();
}