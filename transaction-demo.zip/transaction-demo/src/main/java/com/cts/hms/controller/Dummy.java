package com.cts.hms.controller;

import java.time.LocalDate;

public class Dummy {
	public static void main(String[] args) {
		LocalDate dt=LocalDate.now();
		LocalDate result = dt.plusDays(7);
		System.out.println(result);
	}
}
