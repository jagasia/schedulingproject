package com.cts.hms.entity;

public class Flight {
	private Long id;
	private String name;
	private Integer capacity;
	public Flight() {}
	public Flight(Long id, String name, Integer capacity) {
		super();
		this.id = id;
		this.name = name;
		this.capacity = capacity;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getCapacity() {
		return capacity;
	}
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	@Override
	public String toString() {
		return "Flight [id=" + id + ", name=" + name + ", capacity=" + capacity + "]";
	}
	
}
