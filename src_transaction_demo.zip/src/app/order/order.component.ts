import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { CartService } from '../cart.service';
import { Order } from '../order';
import { OrderService } from '../order.service';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  products:any;
  constructor(private ps:ProductService, private os:OrderService, private cartService:CartService) { }

  ngOnInit(): void {
    this.ps.getAllProducts().subscribe((data)=>{
      this.products=data;
    });
  }

  fnBuy(id)
  {
    alert(id);
    if(localStorage.getItem('customer')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str=localStorage.getItem('customer');
    var customer=JSON.parse(str);
    var customer_id=customer.id;
    var order=new Order();
    order.orderDate=new Date();
    order.productId=id;
    order.customerId=customer_id;
    order.quantity=1;
    console.log("Going to place an order as below");
    console.log(order);
    this.os.placeOrder(order).subscribe(data=>console.log(data));
  }

  fnAddToCart(id)
  {
    // alert(id);
    if(localStorage.getItem('customer')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str=localStorage.getItem('customer');
    var customer=JSON.parse(str);
    var customer_id=customer.id;

    var product_id=id;
    var cart:Cart=new Cart();
    cart.id=0;      //dummy
    cart.customer_id=customer_id;
    cart.product_id=product_id;
    console.log("sending the below cart object to rest api now:");
    console.log(cart);
    this.cartService.add2Cart(customer_id,product_id).subscribe((data)=>{
      console.log(data);
    });
  }
}
