import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url:string="http://localhost:8080/product";
  constructor(private http:HttpClient) { }

  addProduct(product:any)
  {
    return this.http.post(this.url,product);
  }
  getAllProducts()
  {
    return this.http.get(this.url);
  }
  findProductById(id:any)
  {
    return this.http.get(this.url+"/"+id);
  }
  findProductsByCategory(category:string)
  {
    return this.http.get(this.url+"/category/"+category);
  }
  getCategories()
  {
    return this.http.get(this.url+"/categories");
  }
  modifyProduct(product:any)
  {
    return this.http.put(this.url,product);
  }
  removeProduct(id:any)
  {
    return this.http.delete(this.url+"/"+id);
  }
}
