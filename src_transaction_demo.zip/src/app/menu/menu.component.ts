import { Component, DoCheck, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit, DoCheck {
  status:string='login';
  constructor(private cs:CustomerService) { }

  ngDoCheck(): void {
    this.cs.getStatus().subscribe(data=>{      
      if(localStorage.getItem("customer")==null)
      {
        //has not logged in
        this.status="login";
        // console.log("data is null");
      }else
      {
        this.status="logout";
        // console.log("data is not not not null");
      }
    });
  }

  ngOnInit(): void {
  }

}
